# Railway Deployment Guide - 24/7 Bot System

## Quick Setup for 24/7 Operation

### Step 1: Set Environment Variable (IMPORTANT)

In your Railway project dashboard:
1. Go to your project settings
2. Click "Variables" tab
3. Add a new variable:
   - **Name:** `BOT_TOKEN`
   - **Value:** Your actual Telegram bot token (e.g., `123456789:ABCdefGhI...`)
4. Click "Save"

### Step 2: Deploy from GitHub

1. Push your code to GitHub repository
2. In Railway, click "Deploy from GitHub"
3. Select your repository
4. Railway will automatically build and deploy

### Step 3: Verify 24/7 Operation

1. Visit your Railway app URL (e.g., `https://your-app.up.railway.app`)
2. The bot token should be automatically loaded from environment variable
3. Bot will start automatically and run 24/7
4. Admin panel will show "🟢 Bot Running" status

## Why This Fixes the Problem

**Before:** Bot token was only stored in session/temporary files, lost on restart
**After:** Bot token stored in Railway environment variable, persists through restarts

## Environment Variables Explained

- `BOT_TOKEN`: Your Telegram bot token (persistent storage)
- `PORT`: Automatically set by Railway (usually 5000)
- `DATABASE_URL`: Optional - for external database (SQLite works fine)

## Troubleshooting

**If bot token disappears:**
1. Check Railway environment variables are set
2. Redeploy if needed
3. Bot will auto-restart with persistent token

**If bot doesn't start:**
1. Check Railway logs for errors
2. Verify bot token is valid
3. Check admin panel status

## 24/7 Features Enabled

- ✅ Bot runs continuously (no sleep)
- ✅ Auto-restart on failure
- ✅ Persistent token storage
- ✅ Database persists through restarts
- ✅ Admin panel always accessible
- ✅ All coin settings preserved

Your system is now production-ready for 24/7 operation!