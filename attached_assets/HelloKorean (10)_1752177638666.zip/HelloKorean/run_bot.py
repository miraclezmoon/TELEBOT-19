#!/usr/bin/env python3
"""
독립적인 봇 실행 스크립트
"""
import os
import sys
import logging
from bot import TelegramBot
from database import Database

# 로깅 설정
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

def main():
    # 토큰 파일에서 읽기
    token_file = "bot_token.txt"
    
    if not os.path.exists(token_file):
        logger.error(f"토큰 파일 {token_file}이 없습니다. 어드민 패널에서 먼저 토큰을 저장하세요.")
        return
    
    try:
        with open(token_file, 'r') as f:
            token = f.read().strip()
        
        if not token:
            logger.error("토큰이 비어있습니다.")
            return
        
        logger.info(f"봇 시작 중... 토큰: {token[:10]}...")
        
        # 데이터베이스 및 봇 초기화
        db = Database()
        bot = TelegramBot(db, token)
        
        # 봇 실행
        bot.run()
        
    except Exception as e:
        logger.error(f"봇 실행 중 오류: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()