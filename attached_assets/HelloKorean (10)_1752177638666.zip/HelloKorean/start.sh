#!/bin/bash
# Production startup script for permanent deployment

echo "Starting production deployment..."

# Start keep-alive system in background
python keep_alive.py &
KEEPALIVE_PID=$!
echo "Keep-alive system started with PID: $KEEPALIVE_PID"

# Start Streamlit admin panel
echo "Starting Streamlit admin panel..."
streamlit run app.py --server.port 5000 --server.address 0.0.0.0 --server.headless true

# If we reach here, Streamlit has stopped, so stop keep-alive too
echo "Streamlit stopped, stopping keep-alive..."
kill $KEEPALIVE_PID 2>/dev/null