import logging
from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes
import os

# 로깅 설정
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """간단한 start 명령어"""
    logger.info(f"Start command received from {update.effective_user.id}")
    await update.message.reply_text("안녕하세요! 봇이 작동합니다!")

def test_bot(token: str):
    """테스트 봇 실행"""
    logger.info(f"Starting test bot with token: {token[:10]}...")
    
    application = Application.builder().token(token).build()
    application.add_handler(CommandHandler("start", start))
    
    logger.info("Handler registered, starting polling...")
    application.run_polling()

if __name__ == "__main__":
    token = input("봇 토큰을 입력하세요: ")
    test_bot(token)