#!/usr/bin/env python3
"""
Startup script for 24/7 bot deployment
Automatically starts the bot when the system starts
"""
import os
import sys
import time
import logging
import subprocess
from pathlib import Path

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('bot_startup.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def check_bot_token():
    """Check if bot token exists"""
    token_file = "bot_token.txt"
    if os.path.exists(token_file):
        with open(token_file, 'r') as f:
            token = f.read().strip()
        return bool(token)
    return False

def start_bot():
    """Start the bot process"""
    try:
        logger.info("Starting bot process...")
        process = subprocess.Popen(
            ['python', 'run_bot.py'],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            cwd=os.getcwd()
        )
        logger.info(f"Bot started with PID: {process.pid}")
        return process
    except Exception as e:
        logger.error(f"Failed to start bot: {e}")
        return None

def monitor_bot_process(process):
    """Monitor bot process and restart if needed"""
    while True:
        try:
            # Check if process is still running
            if process.poll() is not None:
                logger.warning("Bot process stopped, restarting...")
                process = start_bot()
                if not process:
                    logger.error("Failed to restart bot, waiting 30 seconds...")
                    time.sleep(30)
                    continue
            
            # Wait before next check
            time.sleep(60)  # Check every minute
            
        except KeyboardInterrupt:
            logger.info("Shutdown requested, stopping bot...")
            if process:
                process.terminate()
            break
        except Exception as e:
            logger.error(f"Error monitoring bot: {e}")
            time.sleep(30)

def main():
    """Main startup function"""
    logger.info("=== Bot Startup System ===")
    
    # Check if bot token is configured
    if not check_bot_token():
        logger.warning("No bot token found. Please configure via admin panel first.")
        logger.info("Admin panel should be running on port 5000")
        return
    
    # Start the bot
    bot_process = start_bot()
    if not bot_process:
        logger.error("Failed to start bot on startup")
        return
    
    logger.info("Bot started successfully for 24/7 operation")
    
    # Monitor the bot process
    monitor_bot_process(bot_process)

if __name__ == "__main__":
    main()