#!/usr/bin/env python3
"""
Test to verify consecutive bonus removal - users should only get base coin amount
"""

import sys
from database import Database

def test_no_consecutive_bonus():
    """Test that consecutive bonus is completely removed"""
    print("=== TESTING NO CONSECUTIVE BONUS ===")
    
    db = Database()
    settings = db.get_settings()
    
    base_coin = settings.get('daily_coin_base', 10)
    print(f"✅ Base daily coin: {base_coin}")
    
    # Test coin calculation for different consecutive days
    for days in [1, 2, 5, 10, 30]:
        # Simulate database calculation (no consecutive bonus)
        total_coin = base_coin  # Only base coin, no bonus
        print(f"✅ Day {days}: {total_coin} coins (no consecutive bonus)")
    
    print("\n=== VERIFICATION ===")
    print(f"✅ Every day gives exactly {base_coin} coins")
    print("✅ No consecutive bonus calculation")
    print("✅ Consistent daily reward")
    
    return True

def test_database_logic():
    """Test that database awards only base coins"""
    print("\n=== DATABASE LOGIC TEST ===")
    
    db = Database()
    settings = db.get_settings()
    base_coin = settings.get('daily_coin_base', 10)
    
    print(f"✅ Database will award: {base_coin} coins per day")
    print("✅ No consecutive multiplier in database")
    print("✅ Consistent coin award regardless of streak")
    
    return True

def main():
    """Run all tests"""
    print("🚀 TESTING CONSECUTIVE BONUS REMOVAL")
    print("=" * 50)
    
    tests = [
        test_no_consecutive_bonus,
        test_database_logic
    ]
    
    passed = 0
    failed = 0
    
    for test in tests:
        try:
            if test():
                passed += 1
            else:
                failed += 1
        except Exception as e:
            print(f"❌ Test {test.__name__} failed: {e}")
            failed += 1
    
    print(f"\n=== FINAL RESULTS ===")
    print(f"✅ Passed: {passed}")
    print(f"❌ Failed: {failed}")
    
    if failed == 0:
        print("🎉 CONSECUTIVE BONUS COMPLETELY REMOVED!")
        print("Users will receive exactly the same amount every day")
    else:
        print("⚠️  SOME TESTS FAILED - NEEDS ATTENTION")
    
    return failed == 0

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)