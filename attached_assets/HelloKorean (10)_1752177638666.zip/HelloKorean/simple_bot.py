#!/usr/bin/env python3
"""
간단한 텔레그램 봇 테스트
"""
import asyncio
import logging
from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes
import sys

# 로깅 설정
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Start 명령 처리"""
    user = update.effective_user
    logger.info(f"Start command from user: {user.id} (@{user.username})")
    
    await update.message.reply_text(
        f"안녕하세요 {user.first_name}님! 🎉\n"
        f"텔레그램 봇이 정상적으로 작동하고 있습니다.\n"
        f"사용자 ID: {user.id}"
    )

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Help 명령 처리"""
    await update.message.reply_text(
        "사용 가능한 명령어:\n"
        "/start - 봇 시작\n"
        "/help - 도움말"
    )

def main():
    """메인 함수"""
    if len(sys.argv) < 2:
        print("사용법: python simple_bot.py <BOT_TOKEN>")
        sys.exit(1)
    
    token = sys.argv[1]
    logger.info(f"봇 시작 중... 토큰: {token[:10]}...")
    
    # 봇 애플리케이션 생성
    application = Application.builder().token(token).build()
    
    # 핸들러 등록
    application.add_handler(CommandHandler("start", start_command))
    application.add_handler(CommandHandler("help", help_command))
    
    logger.info("핸들러 등록 완료")
    
    # 봇 실행
    logger.info("폴링 시작...")
    application.run_polling(drop_pending_updates=True)

if __name__ == "__main__":
    main()