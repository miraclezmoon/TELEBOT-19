#!/usr/bin/env python3
"""
Keep-alive script for 24/7 bot deployment
Ensures bot stays running even after deployment restarts
"""
import os
import sys
import time
import logging
import subprocess
import signal
from pathlib import Path

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('keep_alive.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class BotKeepAlive:
    def __init__(self):
        self.bot_process = None
        self.running = True
        
    def signal_handler(self, signum, frame):
        """Handle shutdown signals"""
        logger.info(f"Received signal {signum}, shutting down...")
        self.running = False
        if self.bot_process:
            self.bot_process.terminate()
        sys.exit(0)
    
    def check_token_exists(self):
        """Check if bot token is available"""
        # Check environment variable first
        if os.environ.get('BOT_TOKEN'):
            return True
        
        # Check database settings
        try:
            from database import Database
            db = Database()
            settings = db.get_settings()
            if settings.get('bot_token'):
                return True
        except Exception:
            pass
        
        # Check token file as fallback
        return os.path.exists('bot_token.txt')
    
    def start_bot(self):
        """Start the bot process"""
        try:
            if not self.check_token_exists():
                logger.warning("No bot token found. Bot will start when token is configured.")
                return None
            
            # Get bot token from multiple sources
            bot_token = (
                os.environ.get('BOT_TOKEN') or 
                self.get_token_from_database() or 
                self.get_token_from_file()
            )
            
            if not bot_token:
                logger.warning("No valid bot token found.")
                return None
                
            # Set environment variable for the bot process
            env = os.environ.copy()
            env['BOT_TOKEN'] = bot_token
            
            logger.info("Starting bot process...")
            process = subprocess.Popen(
                ['python', 'run_bot.py'],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                cwd=os.getcwd(),
                env=env
            )
            logger.info(f"Bot started with PID: {process.pid}")
            return process
            
        except Exception as e:
            logger.error(f"Failed to start bot: {e}")
            return None
    
    def get_token_from_database(self):
        """Get bot token from database settings"""
        try:
            from database import Database
            db = Database()
            settings = db.get_settings()
            return settings.get('bot_token')
        except Exception:
            return None
    
    def get_token_from_file(self):
        """Get bot token from file"""
        try:
            if os.path.exists('bot_token.txt'):
                with open('bot_token.txt', 'r') as f:
                    return f.read().strip()
        except Exception:
            pass
        return None
    
    def is_bot_running(self):
        """Check if bot process is still running"""
        if not self.bot_process:
            return False
        return self.bot_process.poll() is None
    
    def restart_bot(self):
        """Restart the bot process"""
        if self.bot_process:
            try:
                self.bot_process.terminate()
                self.bot_process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                self.bot_process.kill()
        
        self.bot_process = self.start_bot()
        return self.bot_process is not None
    
    def monitor_loop(self):
        """Main monitoring loop"""
        logger.info("=== Starting 24/7 Bot Keep-Alive System ===")
        
        # Register signal handlers
        signal.signal(signal.SIGINT, self.signal_handler)
        signal.signal(signal.SIGTERM, self.signal_handler)
        
        # Initial bot start
        self.bot_process = self.start_bot()
        
        check_interval = 30  # Check every 30 seconds
        token_check_interval = 300  # Check for token every 5 minutes
        last_token_check = 0
        
        while self.running:
            try:
                current_time = time.time()
                
                # Check if token became available
                if current_time - last_token_check > token_check_interval:
                    if not self.bot_process and self.check_token_exists():
                        logger.info("Token detected, starting bot...")
                        self.bot_process = self.start_bot()
                    last_token_check = current_time
                
                # Check if bot is still running
                if self.bot_process and not self.is_bot_running():
                    logger.warning("Bot process stopped, restarting...")
                    if self.restart_bot():
                        logger.info("Bot restarted successfully")
                    else:
                        logger.error("Failed to restart bot, will try again in 30 seconds")
                
                # Wait before next check
                time.sleep(check_interval)
                
            except KeyboardInterrupt:
                logger.info("Shutdown requested")
                break
            except Exception as e:
                logger.error(f"Error in monitoring loop: {e}")
                time.sleep(30)
        
        logger.info("Keep-alive system shutting down...")

def main():
    """Main entry point"""
    keep_alive = BotKeepAlive()
    keep_alive.monitor_loop()

if __name__ == "__main__":
    main()