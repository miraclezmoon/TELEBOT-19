import random
import string
from datetime import datetime, date
from typing import Optional

def generate_referral_code(length: int = 8) -> str:
    """추천 코드 생성"""
    characters = string.ascii_uppercase + string.digits
    return ''.join(random.choice(characters) for _ in range(length))

def format_korean_date(date_str: str) -> str:
    """한국어 날짜 형식으로 변환"""
    try:
        if isinstance(date_str, str):
            dt = datetime.fromisoformat(date_str.replace('Z', '+00:00'))
        else:
            dt = date_str
        
        return dt.strftime("%Y년 %m월 %d일")
    except:
        return str(date_str)

def format_korean_datetime(datetime_str: str) -> str:
    """한국어 날짜시간 형식으로 변환"""
    try:
        if isinstance(datetime_str, str):
            dt = datetime.fromisoformat(datetime_str.replace('Z', '+00:00'))
        else:
            dt = datetime_str
        
        return dt.strftime("%Y년 %m월 %d일 %H시 %M분")
    except:
        return str(datetime_str)

def calculate_coin_bonus(consecutive_days: int, base_coin: int = 10) -> int:
    """연속 체크인에 따른 보너스 코인 계산"""
    bonus = min(consecutive_days * 2, 50)  # 최대 50코인 보너스
    return base_coin + bonus

def validate_referral_code(code: str) -> bool:
    """추천 코드 유효성 검증"""
    if not code or len(code) != 8:
        return False
    
    # 영대문자와 숫자만 허용
    return all(c in string.ascii_uppercase + string.digits for c in code)

def format_number_korean(number: int) -> str:
    """숫자를 한국어 형식으로 포맷팅"""
    if number >= 100000000:  # 1억 이상
        return f"{number // 100000000}억 {(number % 100000000) // 10000}만"
    elif number >= 10000:  # 1만 이상
        return f"{number // 10000}만 {number % 10000}"
    else:
        return str(number)

def get_raffle_status_emoji(status: str) -> str:
    """래플 상태에 따른 이모지 반환"""
    status_emojis = {
        'active': '🟢',
        'completed': '🔴',
        'cancelled': '⚫',
        'pending': '🟡'
    }
    return status_emojis.get(status, '❓')

def get_product_category_emoji(category: str) -> str:
    """상품 카테고리에 따른 이모지 반환"""
    category_emojis = {
        '음료': '☕',
        '음식': '🍽️',
        '기프트카드': '🎁',
        '디지털상품': '💻',
        '실물상품': '📦',
        '기타': '🔖'
    }
    return category_emojis.get(category, '🛍️')

def calculate_user_level(total_checkins: int) -> dict:
    """사용자 레벨 계산"""
    levels = [
        {'name': '새싹', 'min_checkins': 0, 'emoji': '🌱'},
        {'name': '새내기', 'min_checkins': 7, 'emoji': '🐣'},
        {'name': '열심이', 'min_checkins': 30, 'emoji': '🔥'},
        {'name': '베테랑', 'min_checkins': 100, 'emoji': '⭐'},
        {'name': '마스터', 'min_checkins': 365, 'emoji': '👑'},
        {'name': '전설', 'min_checkins': 1000, 'emoji': '🏆'}
    ]
    
    current_level = levels[0]
    for level in levels:
        if total_checkins >= level['min_checkins']:
            current_level = level
        else:
            break
    
    return current_level

def is_weekend(date_obj: date) -> bool:
    """주말인지 확인"""
    return date_obj.weekday() >= 5  # 5: 토요일, 6: 일요일

def get_next_checkin_bonus(consecutive_days: int) -> int:
    """다음 체크인 보너스 계산"""
    next_day = consecutive_days + 1
    return calculate_coin_bonus(next_day) - calculate_coin_bonus(consecutive_days)

def sanitize_input(text: str, max_length: int = 100) -> str:
    """입력 텍스트 정리"""
    if not text:
        return ""
    
    # 기본 정리
    text = text.strip()
    
    # 길이 제한
    if len(text) > max_length:
        text = text[:max_length]
    
    # 특수문자 제거 (기본적인 것만)
    dangerous_chars = ['<', '>', '"', "'", '&']
    for char in dangerous_chars:
        text = text.replace(char, '')
    
    return text

def generate_share_message(referral_code: str, bot_username: str) -> str:
    """공유 메시지 생성"""
    message = f"""
🪙 **코인 리워드 시스템에 함께 해요!**

매일 로그인하고 코인을 모아서 다양한 상품을 받아보세요!

🎁 **특별 혜택:**
• 내 추천으로 가입하면 100 코인 보너스!
• 매일 체크인으로 코인 획득
• 래플 참여로 대박 기회
• 다양한 상품 교환 가능

👇 **지금 바로 시작하기**
https://t.me/{bot_username}?start={referral_code}

#코인리워드 #텔레그램봇 #무료상품
    """
    return message

def get_time_greeting() -> str:
    """시간대별 인사말"""
    current_hour = datetime.now().hour
    
    if 5 <= current_hour < 12:
        return "좋은 아침이에요! 🌅"
    elif 12 <= current_hour < 18:
        return "좋은 오후에요! ☀️"
    elif 18 <= current_hour < 22:
        return "좋은 저녁이에요! 🌆"
    else:
        return "늦은 시간이네요! 🌙"

def calculate_streak_bonus_multiplier(consecutive_days: int) -> float:
    """연속 일수에 따른 보너스 배수 계산"""
    if consecutive_days >= 30:
        return 2.0
    elif consecutive_days >= 14:
        return 1.5
    elif consecutive_days >= 7:
        return 1.2
    else:
        return 1.0

def format_duration(seconds: int) -> str:
    """초를 읽기 쉬운 시간 형식으로 변환"""
    if seconds < 60:
        return f"{seconds}초"
    elif seconds < 3600:
        minutes = seconds // 60
        return f"{minutes}분"
    elif seconds < 86400:
        hours = seconds // 3600
        minutes = (seconds % 3600) // 60
        return f"{hours}시간 {minutes}분"
    else:
        days = seconds // 86400
        hours = (seconds % 86400) // 3600
        return f"{days}일 {hours}시간"
