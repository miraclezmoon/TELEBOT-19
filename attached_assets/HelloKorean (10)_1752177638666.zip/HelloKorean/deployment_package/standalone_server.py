#!/usr/bin/env python3
"""
Standalone server for permanent admin panel deployment
Can be deployed on any hosting platform with a permanent URL
"""
import os
import sys
import time
import signal
import logging
import subprocess
from pathlib import Path
from threading import Thread

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('standalone_server.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class StandaloneServer:
    def __init__(self):
        self.streamlit_process = None
        self.bot_process = None
        self.running = True
        self.port = int(os.environ.get('PORT', 5000))
        self.host = os.environ.get('HOST', '0.0.0.0')
        
    def setup_environment(self):
        """Setup environment for standalone deployment"""
        logger.info("Setting up standalone environment...")
        
        # Ensure required directories exist
        os.makedirs('.streamlit', exist_ok=True)
        os.makedirs('logs', exist_ok=True)
        
        # Create streamlit config for standalone deployment
        config_content = f"""[server]
headless = true
address = "{self.host}"
port = {self.port}
enableCORS = false
enableXsrfProtection = false
maxUploadSize = 1

[browser]
gatherUsageStats = false
showErrorDetails = true

[theme]
base = "light"
"""
        
        with open('.streamlit/config.toml', 'w') as f:
            f.write(config_content)
        
        logger.info(f"Configured for {self.host}:{self.port}")
        
    def start_admin_panel(self):
        """Start the admin panel"""
        try:
            logger.info("Starting standalone admin panel...")
            
            env = os.environ.copy()
            env.update({
                'STREAMLIT_SERVER_HEADLESS': 'true',
                'STREAMLIT_SERVER_PORT': str(self.port),
                'STREAMLIT_SERVER_ADDRESS': self.host,
                'STREAMLIT_BROWSER_GATHER_USAGE_STATS': 'false'
            })
            
            cmd = [
                sys.executable, '-m', 'streamlit', 'run', 'app.py',
                '--server.port', str(self.port),
                '--server.address', self.host,
                '--server.headless', 'true',
                '--browser.gatherUsageStats', 'false'
            ]
            
            self.streamlit_process = subprocess.Popen(
                cmd,
                env=env,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )
            
            logger.info(f"Admin panel started on {self.host}:{self.port} (PID: {self.streamlit_process.pid})")
            return True
            
        except Exception as e:
            logger.error(f"Failed to start admin panel: {e}")
            return False
    
    def start_bot_system(self):
        """Start the bot keep-alive system"""
        try:
            logger.info("Starting bot keep-alive system...")
            
            self.bot_process = subprocess.Popen(
                [sys.executable, 'keep_alive.py'],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )
            
            logger.info(f"Bot system started (PID: {self.bot_process.pid})")
            return True
            
        except Exception as e:
            logger.error(f"Failed to start bot system: {e}")
            return False
    
    def monitor_services(self):
        """Monitor both services and restart if needed"""
        logger.info("Starting service monitoring...")
        
        while self.running:
            try:
                # Check admin panel
                if self.streamlit_process and self.streamlit_process.poll() is not None:
                    logger.warning("Admin panel stopped, restarting...")
                    self.start_admin_panel()
                
                # Check bot system
                if self.bot_process and self.bot_process.poll() is not None:
                    logger.warning("Bot system stopped, restarting...")
                    self.start_bot_system()
                
                time.sleep(30)  # Check every 30 seconds
                
            except Exception as e:
                logger.error(f"Error in service monitoring: {e}")
                time.sleep(30)
    
    def signal_handler(self, signum, frame):
        """Handle shutdown signals"""
        logger.info(f"Received signal {signum}, shutting down...")
        self.running = False
        self.stop_all_services()
        sys.exit(0)
    
    def stop_all_services(self):
        """Stop all services"""
        logger.info("Stopping all services...")
        
        if self.streamlit_process:
            try:
                self.streamlit_process.terminate()
                self.streamlit_process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                self.streamlit_process.kill()
        
        if self.bot_process:
            try:
                self.bot_process.terminate()
                self.bot_process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                self.bot_process.kill()
    
    def health_check_endpoint(self):
        """Simple health check for monitoring"""
        return {
            'status': 'healthy' if self.running else 'stopped',
            'admin_panel': 'running' if self.streamlit_process and self.streamlit_process.poll() is None else 'stopped',
            'bot_system': 'running' if self.bot_process and self.bot_process.poll() is None else 'stopped',
            'port': self.port,
            'host': self.host
        }
    
    def run_standalone(self):
        """Run the standalone server"""
        logger.info("=== Starting Standalone Admin Panel Server ===")
        logger.info(f"Server will be accessible at http://{self.host}:{self.port}")
        
        # Setup signal handlers
        signal.signal(signal.SIGINT, self.signal_handler)
        signal.signal(signal.SIGTERM, self.signal_handler)
        
        # Setup environment
        self.setup_environment()
        
        # Start services
        if not self.start_admin_panel():
            logger.error("Failed to start admin panel")
            return False
        
        # Wait for admin panel to be ready
        time.sleep(5)
        
        if not self.start_bot_system():
            logger.error("Failed to start bot system")
            return False
        
        logger.info("=== Standalone Server Ready ===")
        logger.info("All services running and monitored")
        logger.info("Server ready for production use")
        
        # Start monitoring
        self.monitor_services()
        
        return True

def main():
    """Main function for standalone deployment"""
    server = StandaloneServer()
    
    try:
        success = server.run_standalone()
        if not success:
            logger.error("Failed to start standalone server")
            sys.exit(1)
    except KeyboardInterrupt:
        logger.info("Server stopped by user")
    except Exception as e:
        logger.error(f"Server error: {e}")
        sys.exit(1)
    finally:
        server.stop_all_services()

if __name__ == "__main__":
    main()