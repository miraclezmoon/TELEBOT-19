from dataclasses import dataclass
from datetime import datetime, date
from typing import Optional, List

@dataclass
class User:
    user_id: int
    username: Optional[str]
    full_name: str
    chat_id: Optional[int]
    coins: int = 0
    total_earned: int = 0
    referral_code: Optional[str] = None
    referred_by: Optional[int] = None
    joined_date: datetime = None
    last_checkin: Optional[date] = None
    consecutive_checkins: int = 0
    total_checkins: int = 0
    raffle_entries: int = 0
    raffle_wins: int = 0

@dataclass
class DailyCheckin:
    id: int
    user_id: int
    checkin_date: date
    coins_earned: int
    consecutive_days: int

@dataclass
class Raffle:
    id: int
    name: str
    description: Optional[str]
    prize: str
    entry_cost: int
    max_entries: Optional[int]
    start_date: datetime
    end_date: datetime
    winner_id: Optional[int] = None
    status: str = 'active'
    created_at: datetime = None

@dataclass
class RaffleEntry:
    id: int
    raffle_id: int
    user_id: int
    entry_date: datetime
    coins_spent: int

@dataclass
class Product:
    id: int
    name: str
    description: Optional[str]
    price: int
    stock: int
    category: Optional[str]
    image_url: Optional[str] = None
    is_active: bool = True
    created_at: datetime = None

@dataclass
class Purchase:
    id: int
    user_id: int
    product_id: int
    coins_spent: int
    purchase_date: datetime
    status: str = 'completed'

@dataclass
class Referral:
    id: int
    referrer_id: int
    referee_id: int
    referral_code: str
    bonus_coins: int = 0
    created_at: datetime = None

@dataclass
class CoinTransaction:
    id: int
    user_id: int
    amount: int
    transaction_type: str  # 'earn' or 'spend'
    description: Optional[str]
    created_at: datetime
