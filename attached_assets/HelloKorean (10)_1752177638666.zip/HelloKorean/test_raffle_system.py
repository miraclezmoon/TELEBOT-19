#!/usr/bin/env python3

from database import Database

def test_raffle_system():
    db = Database()
    
    print("=== Testing Raffle System ===")
    
    # Test getting active raffles
    active_raffles = db.get_active_raffles()
    print(f"Active raffles found: {len(active_raffles)}")
    
    for raffle in active_raffles:
        print(f"\nRaffle Details:")
        print(f"- ID: {raffle['id']}")
        print(f"- Name: {raffle['name']}")
        print(f"- Prize: {raffle['prize']}")
        print(f"- Entry Cost: {raffle['entry_cost']} coins")
        print(f"- End Date: {raffle['end_date']}")
        
        # Test button creation simulation
        button_text = f"🎯 Join {raffle['name']}"
        callback_data = f"join_raffle_{raffle['id']}"
        print(f"- Button Text: {button_text}")
        print(f"- Callback Data: {callback_data}")

if __name__ == "__main__":
    test_raffle_system()